package com.pillgood.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.pillgood.dto.ReturnDto;
import com.pillgood.entity.Return;
import com.pillgood.repository.ReturnRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ReturnServiceImpl implements ReturnService {

    private final ReturnRepository returnRepository;

    @Override
    public List<ReturnDto> getAllReturns() {
        return returnRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public ReturnDto getReturnById(int returnId) {
        Optional<Return> returnOpt = returnRepository.findById(returnId);
        return returnOpt.map(this::convertToDto).orElse(null);
    }

    @Override
    public ReturnDto createReturn(ReturnDto returnDto) {
        Return returnEntity = convertToEntity(returnDto);
        returnRepository.save(returnEntity);
        return convertToDto(returnEntity);
    }

    @Override
    public ReturnDto updateReturn(int returnId, ReturnDto returnDto) {
        Optional<Return> returnOpt = returnRepository.findById(returnId);
        if (returnOpt.isPresent()) {
            Return returnEntity = returnOpt.get();
            returnEntity.setRequestDate(returnDto.getRequestDate());
            returnEntity.setReceivedDate(returnDto.getReceivedDate());
            returnEntity.setProcessedDate(returnDto.getProcessedDate());
            returnEntity.setCancelledDate(returnDto.getCancelledDate());
            returnEntity.setOrderNo(returnDto.getOrderNo());
            returnEntity.setReturnStatus(returnDto.getReturnStatus());
            returnRepository.save(returnEntity);
            return convertToDto(returnEntity);
        }
        return null;
    }

    @Override
    public void deleteReturn(int returnId) {
        returnRepository.deleteById(returnId);
    }

    private ReturnDto convertToDto(Return returnEntity) {
        return new ReturnDto(
                returnEntity.getReturnId(),
                returnEntity.getRequestDate(),
                returnEntity.getReceivedDate(),
                returnEntity.getProcessedDate(),
                returnEntity.getCancelledDate(),
                returnEntity.getOrderNo(),
                returnEntity.getReturnStatus()
        );
    }

    private Return convertToEntity(ReturnDto returnDto) {
        return new Return(
                returnDto.getReturnId(),
                returnDto.getRequestDate(),
                returnDto.getReceivedDate(),
                returnDto.getProcessedDate(),
                returnDto.getCancelledDate(),
                returnDto.getOrderNo(),
                returnDto.getReturnStatus()
        );
    }
}
