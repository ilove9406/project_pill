package com.pillgood.service;

import java.util.List;

import com.pillgood.dto.PaymentDto;

public interface PaymentService {
    List<PaymentDto> getAllPayments();
    PaymentDto getPaymentById(String paymentNo);
    PaymentDto createPayment(PaymentDto paymentDto);
    PaymentDto updatePayment(String paymentNo, PaymentDto paymentDto);
    void deletePayment(String paymentNo);
}
