package com.pillgood.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class PaymentDto {
    private String paymentNo;
    private String paymentMethod;
    private int paymentAmount;
    private String orderNo;
    private LocalDateTime paymentDate;
    private String paymentStatus;
    private boolean subscriptionPaymentStatus;
}
