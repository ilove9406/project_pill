package com.pillgood.service;

import java.util.List;

import com.pillgood.dto.ReturnDto;

public interface ReturnService {
    List<ReturnDto> getAllReturns();
    ReturnDto getReturnById(int returnId);
    ReturnDto createReturn(ReturnDto returnDto);
    ReturnDto updateReturn(int returnId, ReturnDto returnDto);
    void deleteReturn(int returnId);
}
