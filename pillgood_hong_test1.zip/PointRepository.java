/*
package com.pillgood.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pillgood.entity.Point;

public interface PointRepository extends JpaRepository<Point, Integer> {

	List<Point> findByMemberUniqueId(String memberUniqueId);
}
*/

package com.pillgood.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.pillgood.entity.Point;

@Repository
public interface PointRepository extends JpaRepository<Point, Integer> {
    List<Point> findByMemberUniqueId(String memberUniqueId);

    @Query("SELECT p.memberUniqueId, SUM(p.points) AS totalPoints " +
           "FROM Point p " +
           "GROUP BY p.memberUniqueId")
    List<Object[]> findTotalPointsByMember();

    @Query("SELECT p.memberUniqueId, SUM(p.points) AS totalPoints, " +
           "SUM(CASE " +
           "WHEN pd.pointStatusCode = 'PS' THEN pd.points " +
           "WHEN pd.pointStatusCode = 'PU' THEN -pd.points " +
           "ELSE 0 END) AS currentPoints " +
           "FROM Point p " +
           "JOIN PointDetail pd ON p.pointId = pd.pointId " +
           "GROUP BY p.memberUniqueId")
    List<Object[]> findTotalAndCurrentPointsByMember();
}
//새로 만든 부분 쿼리 기능테스트해야함.