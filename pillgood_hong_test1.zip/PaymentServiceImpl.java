package com.pillgood.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pillgood.dto.PaymentDto;
import com.pillgood.entity.Payment;
import com.pillgood.repository.PaymentRepository;

@Service
public class PaymentServiceImpl implements PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Override
    public List<PaymentDto> getAllPayments() {
        return paymentRepository.findAll().stream()
                .map(this::convertToDto)
                .collect(Collectors.toList());
    }

    @Override
    public PaymentDto getPaymentById(String paymentNo) {
        Optional<Payment> paymentOpt = paymentRepository.findById(paymentNo);
        return paymentOpt.map(this::convertToDto).orElse(null);
    }

    @Override
    public PaymentDto createPayment(PaymentDto paymentDto) {
        Payment paymentEntity = convertToEntity(paymentDto);
        paymentRepository.save(paymentEntity);
        return convertToDto(paymentEntity);
    }

    @Override
    public PaymentDto updatePayment(String paymentNo, PaymentDto paymentDto) {
        Optional<Payment> paymentOpt = paymentRepository.findById(paymentNo);
        if (paymentOpt.isPresent()) {
            Payment paymentEntity = paymentOpt.get();
            updateEntityFromDto(paymentEntity, paymentDto);
            paymentRepository.save(paymentEntity);
            return convertToDto(paymentEntity);
        }
        return null;
    }

    @Override
    public void deletePayment(String paymentNo) {
        paymentRepository.deleteById(paymentNo);
    }

    private PaymentDto convertToDto(Payment paymentEntity) {
        return new PaymentDto(
                paymentEntity.getPaymentNo(),
                paymentEntity.getPaymentMethod(),
                paymentEntity.getPaymentAmount(),
                paymentEntity.getOrderNo(),
                paymentEntity.getPaymentDate(),
                paymentEntity.getPaymentStatus(),
                paymentEntity.isSubscriptionPaymentStatus()
        );
    }

    private Payment convertToEntity(PaymentDto paymentDto) {
        return new Payment(
                paymentDto.getPaymentNo(),
                paymentDto.getPaymentMethod(),
                paymentDto.getPaymentAmount(),
                paymentDto.getOrderNo(),
                paymentDto.getPaymentDate(),
                paymentDto.getPaymentStatus(),
                paymentDto.isSubscriptionPaymentStatus()
        );
    }

    private void updateEntityFromDto(Payment paymentEntity, PaymentDto paymentDto) {
        paymentEntity.setPaymentMethod(paymentDto.getPaymentMethod());
        paymentEntity.setPaymentAmount(paymentDto.getPaymentAmount());
        paymentEntity.setOrderNo(paymentDto.getOrderNo());
        paymentEntity.setPaymentDate(paymentDto.getPaymentDate());
        paymentEntity.setPaymentStatus(paymentDto.getPaymentStatus());
        paymentEntity.setSubscriptionPaymentStatus(paymentDto.isSubscriptionPaymentStatus());
    }
}
