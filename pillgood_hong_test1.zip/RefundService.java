package com.pillgood.service;

import java.util.List;
import java.util.Optional;

import com.pillgood.dto.RefundDto;
import com.pillgood.entity.Refund;

public interface RefundService {
    List<RefundDto> getAllRefunds();
    RefundDto getRefundById(int refundId);
    RefundDto createRefund(RefundDto refundDto);
    Optional<RefundDto> updateRefund(int refundId, RefundDto refundDto);
    void deleteRefund(int refundId);
    RefundDto convertToDto(Refund refund);
    Refund convertToEntity(RefundDto refundDto);
}
