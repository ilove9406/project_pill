package com.pillgood.entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "payments")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Payment {

    @Id
    @Column(name = "payment_no", length = 50)
    private String paymentNo;

    @Column(name = "payment_method", length = 50)
    private String paymentMethod;

    @Column(name = "payment_amount")
    private int paymentAmount;

    @Column(name = "order_no", length = 50)
    private String orderNo;

    @Column(name = "payment_date")
    private LocalDateTime paymentDate;

    @Column(name = "payment_status", length = 50)
    private String paymentStatus;

    @Column(name = "subscription_payment_status")
    private boolean subscriptionPaymentStatus;

    @ManyToOne
    @JoinColumn(name = "order_no", insertable = false, updatable = false)
    private Order order;

    public Payment(String paymentNo, String paymentMethod, int paymentAmount, String orderNo, LocalDateTime paymentDate, String paymentStatus, boolean subscriptionPaymentStatus) {
        this.paymentNo = paymentNo;
        this.paymentMethod = paymentMethod;
        this.paymentAmount = paymentAmount;
        this.orderNo = orderNo;
        this.paymentDate = paymentDate;
        this.paymentStatus = paymentStatus;
        this.subscriptionPaymentStatus = subscriptionPaymentStatus;
    }
}
