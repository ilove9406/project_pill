
package com.pillgood.service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.pillgood.dto.PointDto;
import com.pillgood.entity.Point;
import com.pillgood.repository.PointRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PointServiceImpl implements PointService {

    private final PointRepository pointRepository;

    @Override
    public List<PointDto> getAllPoints() {
        return pointRepository.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public List<PointDto> getPointsByMemberUniqueId(String memberUniqueId) {
        return pointRepository.findByMemberUniqueId(memberUniqueId).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public PointDto createPoint(PointDto PointDto) {
        Point point = convertToEntity(PointDto);
        Point savedPoint = pointRepository.save(point);
        return convertToDTO(savedPoint);
    }

    @Override
    public Optional<PointDto> updatePoint(int id, PointDto updatedPointDto) {
        return pointRepository.findById(id)
                .map(point -> {
                    point.setMemberUniqueId(updatedPointDto.getMemberUniqueId());
                    point.setPointMasterId(updatedPointDto.getPointMasterId());
                    point.setPointStatusCode(updatedPointDto.getPointStatusCode());
                    point.setPoints(updatedPointDto.getPoints());
                    point.setTransactionDate(updatedPointDto.getTransactionDate());
                    point.setExpiryDate(updatedPointDto.getExpiryDate());
                    point.setReferenceId(updatedPointDto.getReferenceId());
                    Point updatedPoint = pointRepository.save(point);
                    return convertToDTO(updatedPoint);
                });
    }

    @Override
    public boolean deletePoint(int id) {
        if (pointRepository.existsById(id)) {
            pointRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public PointDto convertToDTO(Point point) {
        return new PointDto(
                point.getPointId(),
                point.getMemberUniqueId(),
                point.getPointMasterId(),
                point.getPointStatusCode(),
                point.getPoints(),
                point.getTransactionDate(),
                point.getExpiryDate(),
                point.getReferenceId()
        );
    }

    @Override
    public Point convertToEntity(PointDto PointDto) {
        return new Point(
                PointDto.getPointId(),
                PointDto.getMemberUniqueId(),
                PointDto.getPointMasterId(),
                PointDto.getPointStatusCode(),
                PointDto.getPoints(),
                PointDto.getTransactionDate(),
                PointDto.getExpiryDate(),
                PointDto.getReferenceId()
        );
    }
}
