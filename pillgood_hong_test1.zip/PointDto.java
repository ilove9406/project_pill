
package com.pillgood.dto;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PointDto {
    
    @JsonProperty("point_id")
    private int pointId;
    
    @JsonProperty("member_unique_id")
    private String memberUniqueId;
    
    @JsonProperty("point_master_id")
    private String pointMasterId;
    
    @JsonProperty("point_status_code")
    private String pointStatusCode;
    
    @JsonProperty("points")
    private int points;
    
    @JsonProperty("transaction_date")
    private LocalDateTime transactionDate;
    
    @JsonProperty("expiry_date")
    private LocalDateTime expiryDate;
    
    @JsonProperty("reference_id")
    private String referenceId;
}
