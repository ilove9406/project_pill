package com.pillgood.service;

import java.util.List;
import java.util.Optional;

import com.pillgood.dto.PointDto;
import com.pillgood.entity.Point;

public interface PointService {
    List<PointDto> getAllPoints();
    List<PointDto> getPointsByMemberUniqueId(String memberUniqueId);
    PointDto createPoint(PointDto PointDto);
    Optional<PointDto> updatePoint(int id, PointDto updatedPointDto);
    boolean deletePoint(int id);
    PointDto convertToDTO(Point point);
    Point convertToEntity(PointDto PointDto);
}
